Academic ADL Co-Lab
June 3, 2004

These files are based on the ADL GenericRunTimeWrapper v1.0. It has been modified to not open content in a new window, creating a more seamless learner experience.

Academic ADL Co-Lab
Sept 20, 2004

Modified to destroy any LMS-provided SCORM 1.2 APIs
