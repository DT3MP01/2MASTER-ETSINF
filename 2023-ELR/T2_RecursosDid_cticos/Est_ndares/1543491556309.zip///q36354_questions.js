 test.AddQuestion( new Question ("com.medpix.clavy.4394341304236931.interactions.q36659_1",
 "Regarding teratoma, which statement is most correct?",
 QUESTION_TYPE_CHOICE,
new Array("The diagnosis of Teratoma requires tissues from all three embryonic germ layers","Teeth are mineralized (calcified) like bone -but they are actually ectoderm, not mesoderm","Mediastinal teratoma arise from an incorporated blighted embryo","Lipid material in a teratoma is produced by mesodermal adipocytes"),
 "Teeth are mineralized (calcified) like bone -but they are actually ectoderm, not mesoderm",
 "obj_playing",
 "https://medpix.nlm.nih.gov/images/full/synpic1007.jpg")
);
 test.AddQuestion( new Question ("com.medpix.clavy.4394341304236931.interactions.q36660_1",
 "Which of the following masses may contain areas of very low attenuation (darker than water)?",
 QUESTION_TYPE_CHOICE,
new Array("Lipoma","Thymic tumors","Teratoma","Dermoid inclusion cyst","All of the above"),
 "All of the above",
 "obj_playing",
 "https://medpix.nlm.nih.gov/images/full/synpic1007.jpg")
);
 test.AddQuestion( new Question ("com.medpix.clavy.4394341304236931.interactions.q36658_1",
 "Based on the images provided, which of these is the most likely diagnosis?",
 QUESTION_TYPE_CHOICE,
new Array("Aortic aneurysm","Teratoma","Germ cell tumor","Thymoma"),
 "Teratoma",
 "obj_playing",
 "https://medpix.nlm.nih.gov/images/full/synpic1007.jpg")
);
