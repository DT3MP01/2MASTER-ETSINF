 function setArray(queryString) {   
var pageArray = new Array();
switch (queryString){
case "36489":
 var pageArray = new Array(1);
pageArray[0] = "36489.html";
break;
case "36354":
 var pageArray = new Array(1);
pageArray[0] = "36354.html";
break;
case "q36354":
 var pageArray = new Array(1);
pageArray[0] = "shared/assessmenttemplate.html?questions=q36354";
break;
default:
alert("error, no match for '" + queryString + "'");
break;
}
return pageArray;
}
