self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9dfe3ea70dd849c835de965f1734037b",
    "url": "@yield('content-viewer-url')/index.html"
  },
  {
    "revision": "2b51878503b95e282f21",
    "url": "@yield('content-viewer-url')/static/css/2.37be29a2.chunk.css"
  },
  {
    "revision": "6641213ef2b872c277c6",
    "url": "@yield('content-viewer-url')/static/css/main.4e272837.chunk.css"
  },
  {
    "revision": "2b51878503b95e282f21",
    "url": "@yield('content-viewer-url')/static/js/2.410870b6.chunk.js"
  },
  {
    "revision": "f6681c7661458c30d69c95815d12061b",
    "url": "@yield('content-viewer-url')/static/js/2.410870b6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6641213ef2b872c277c6",
    "url": "@yield('content-viewer-url')/static/js/main.07c754c1.chunk.js"
  },
  {
    "revision": "05c91422a8ff984def11",
    "url": "@yield('content-viewer-url')/static/js/runtime-main.779b656d.js"
  }
]);